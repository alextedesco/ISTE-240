<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title><?php echo $title; ?></title>
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/css/nav.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
<header id="top"> 
	<div id="toptext">
		Some Title
	</div> 
</header> 
<section id="maincontainer"> 
	<div id="contentwrapper"> 
		<div id="contentcolumn"> 
			<div class="innertube">