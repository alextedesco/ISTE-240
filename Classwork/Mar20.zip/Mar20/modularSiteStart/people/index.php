<?php
	$title = "People";

	include ('assets/inc/header.php');

	include ('assets/inc/nav.php')
?>
		<h1>Home page stuff...</h1> 
		<div>(eventually, each page will be some includes and a db call only!)</div>

<?php			

	include ('assets/inc/footer.php')

?>
				