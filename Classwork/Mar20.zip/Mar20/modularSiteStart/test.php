<?php

    $title = "Title"

?>