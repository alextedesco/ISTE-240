<?php
    $mydate = array("time"=>date("Y-m-d H:i:s") , "favcolor"=>"red");

    // var_dump ($mydate);
    echo json_encode ($mydate);
?>