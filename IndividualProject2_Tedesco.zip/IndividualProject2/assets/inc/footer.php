<!-- Alex Tedesco -->
<!-- ISTE-240 -->
<!-- Individual Project 2 -->

<!-- Footer which is included at the bottom of every PHP file -->

</div>

</body>

</html>