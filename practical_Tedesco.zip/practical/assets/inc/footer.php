<!-- Bonus: Obtain year using PHP -->
<?php
$currYear = date("Y");
?>

<p>Copyright <?php echo $currYear?> Rate My Dog</p>
<br/>
    </div>

</body>
</html>